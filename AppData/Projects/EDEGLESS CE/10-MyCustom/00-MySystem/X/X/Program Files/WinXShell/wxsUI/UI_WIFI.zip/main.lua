function onclick(ctrl)
  if ctrl == 'dialup' then
    app:run('rasphone.exe')
  elseif ctrl == 'netsettings' then
    --control.exe /name Microsoft.NetworkAndSharingCenter
    app:run('WinXShell.exe', 'wxs-open:netsettings')
  elseif ctrl == 'proxysettings' then
    app:run('rundll32.exe', 'Shell32.dll,Control_RunDLL inetcpl.cpl,,4')
  elseif ctrl == 'launch_osk' then
    app:run('osk.exe')
  end
end
