local power_clicked = false

function onload()
    local wp = ''
    local param = app:info('cmdline')
    local blur = string.match(param, '-blur%s([0-9\\.]+)%s?')
    if blur == nil then blur = '0.0' end

    wp = string.match(param, '-bk%s(.+)$')
    if wp == nil then wp = app:call('Desktop::GetWallpaper') end

    local win = sui:find('full_win')
    win.bkimage = "file='" .. wp .. "' blur='" .. blur .. "'"
    sui:moveto(0, 0, 2000, 2000, -1, 64)
end

local function power_helper(wu_param, sd_param)
  local sd = os.getenv("SystemDrive")
  if File.exists(sd ..'\\Windows\\System32\\Wpeutil.exe') then
    suilib.call('run', 'wpeutil.exe', wu_param, 0) -- SW_HIDE(0)
    return 0
  elseif File.exists(sd ..'\\Windows\\System32\\shutdown.exe') then
    suilib.call('run', 'shutdown.exe', sd_param .. ' -t 0')
    return 0
  end
  return 1
end

local function reboot()
    return power_helper('Reboot', '-r')
end

local function shutdown()
    return power_helper('Shutdown', '-s')
end

function onclick(ctrl)
  if power_clicked then return end
  if ctrl == "restartbtn" then
    power_clicked = true
    reboot()
  elseif ctrl == "shutdownbtn" then
    power_clicked = true
    shutdown()
  end
end
